//'use strict';
//const imported = require("./inventory.ES6.js");
//let inventory = imported.inventory;
//let options = Object.keys(inventory);

import inventory from "./inventory.ES6.js";
let options = Object.keys(inventory);

let foundations = options.filter(ingr => inventory[ingr]['foundation']);
let extras = options.filter(ingr => inventory[ingr]['extra']);
let proteins = options.filter(ingr => inventory[ingr]['protein']);
let dressings = options.filter(ingr => inventory[ingr]['dressing'])

class Salad{

  constructor(){
    this.options = [];
  }

  addOption(option, size){ this.options.push({...inventory[option]}) } 
  
  removeOption(option) { this.options = this.options.filter(opt => opt != option); }

  price(){ return this.options.reduce((acc, opt) => acc + opt['price']) }

}

export default Salad;
