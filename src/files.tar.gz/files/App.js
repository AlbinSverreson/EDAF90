import logo from './logo.svg';
import './App.css';
import ComposeSalad from './ComposeSalad';
import ComposeSaladModal from "./ComposeSaladModal";
import React from "react";
import inventory from "./inventory.ES6.js";

class App extends React.Component {
  constructor(props){
    super(props)
    this.state = ({
      order: []
    });
    this.addSalad = this.addSalad.bind(this);
  }
  
  addSalad = (salad) => {
    this.setState({order : [...this.state.order, salad]});
    console.log(this.state)
  }
  
  render() {
    console.log(this);
    return (
      <div>
        <div className="jumbotron text-center">
          <h1 className="display-4">Salad maker 3000</h1>
          <p className="lead">
            Gör din egen salladsjävel.
          </p>
          <hr className="my-4" />
          <p>Detta är lab 2 i EDAF90.</p>
        </div>
        <ComposeSaladModal inventory={inventory} addSalad={this.addSalad} />
      </div>
    );
  }
  
}

export default App;
